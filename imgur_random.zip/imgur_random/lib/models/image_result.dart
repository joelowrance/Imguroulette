import 'package:flutter/widgets.dart';

class ImageResult {
  final String id;
  final NetworkImage image;

  const ImageResult({this.id, this.image});
}
